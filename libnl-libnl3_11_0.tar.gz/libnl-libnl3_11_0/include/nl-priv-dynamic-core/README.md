include/nl-priv-dynamic-core
============================

Contains internal API on top of core (libnl-3). It is
implemented by core and usable to all users that link
against libnl-3.

Note that the ABI, while being internal, should stay stable.

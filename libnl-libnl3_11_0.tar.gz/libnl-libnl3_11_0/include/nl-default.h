/* SPDX-License-Identifier: LGPL-2.1-only */

#ifndef __NL_DEFAULT_H__
#define __NL_DEFAULT_H__

#include "config.h"

#include "base/nl-base-utils.h"

#endif /* __NL_DEFAULT_H__ */
